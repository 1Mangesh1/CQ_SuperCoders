const randomGenerate = require('./randomGenerate');

const random = randomGenerate(1, 50);
console.log("Random Number:", random);

console.log("Random Number + 1: ", random + 1);